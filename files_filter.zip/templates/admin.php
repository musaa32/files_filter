	<?php OCP\Util::addscript('files_filter', 'extended'); ?>
	<form name="extendedSettings" class="section" action="#" method="post">
		<h2><?php p($l->t('File Firewall')); ?></h2>
		
		<p class="">
			<input id="fileTypeRestriction" type="checkbox" <?php if ($_['fileTypeRes'] === 'yes') print_unescaped('checked="checked"');?> name="filetyperes_enabled" original-title="">
			<label for="fileTypeRestriction">Enable file type restriction</label>
			<br/>
		</p>
		<p id="restriction" class="indent <?php if ($_['fileTypeRes'] === 'no') p('hidden');?>">
		<label for="filetypes">Allowed filetypes </label>
		<input type="text" name="allowed_filetypes" style="width: 400px" id="filetypes" value='<?php p($_['allowed_filetypes']) ?>'/> for groups <input name="filetype_group" type="hidden" class="uploadGroups" value="<?php p($_['filetype_group']) ?>" style="width: 400px"/><br>
		<em>Ente the media type e.g. "image/bmp;application/pdf" and specify at least one group. Filter only works for specified groups.</em><br />
		</p>
		
		<br />
		<p>
		<label for="ignored_folders">Ignore these folders</label>
		<input type="text" name="ignored_folders" style="width: 400px" id="ignored_folders" value='<?php p($_['ignored_folders']) ?>'/><br />
		<em>Ente folder names e.g. "/Documents;/Pictures".</em><br />
		</p>
		
	</form>