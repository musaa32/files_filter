<?php
/**
 * @author Musa-A. A. <https://github.com/musaa32>

 *
 * @copyright Copyright (c) 2016, Musa-A. A.
 * @license AGPL-3.0
 *
 * This code is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License, version 3,
 * as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License, version 3,
 * along with this program.  If not, see <http://www.gnu.org/licenses/>
 *
 */
$tmpl = new OCP\Template( 'files_filter', 'admin' );
$filetyprestriction = \OC::$server->getConfig()->getAppValue('core', 'filetyperes_enabled');

$allowed_types =\OC::$server->getConfig()->getAppValue('core', 'allowed_filetypes');

$ignored_folders = \OC::$server->getConfig()->getAppValue('core', 'ignored_folders');

$filetype_group = \OC::$server->getConfig()->getAppValue('core', 'filetype_group');
$filetype_group = explode(',', $filetype_group);

$tmpl->assign('filetype_group', implode('|', $filetype_group));
$tmpl->assign('fileTypeRes', $filetyprestriction);
$tmpl->assign('allowed_filetypes', $allowed_types);

$tmpl->assign('ignored_folders', $ignored_folders);
return $tmpl->fetchPage();
