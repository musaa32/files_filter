<?php
/**
 * @author Musa-A. A. <https://github.com/musaa32>

 *
 * @copyright Copyright (c) 2016, Musa-A. A.
 * @license AGPL-3.0
 *
 * This code is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License, version 3,
 * as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License, version 3,
 * along with this program.  If not, see <http://www.gnu.org/licenses/>
 *
 */
namespace OCA\Files_Filter;
use \OCP\Lock\ILockingProvider;

class Hooks {

	

	
	/**
	 * Delete file after upload if not allowed.
	 * 
	 * @param array $params
	 */
	public static function post_create_hook($params) {
		
		 
		
		// if run is set, skip skeleton files
		if(array_key_exists('run', $params))
			return;
			
			
			
		if(!array_key_exists('path', $params))
			return;	
			
			
			
		
		
				
		$enabled = \OCA\Files_Filter\Helper::FilterEnabledForUser();
		if(!$enabled)
			return;
				
		$path = $params['path'];
		
		if($path == "/")
			return;
		
		
		if(\OCA\Files_Filter\Helper::SkipFolder($path))
			return;
		
		
		$index = strrpos($path, "/");
		$dir = substr($path,0,$index);
		$filename =  array((string)substr(strrchr($path, "/"), 1));
		$files = $filename;
	
		
			
		$user = \OCP\User::getUser();
		if($user == null || $user == '')
			return;
			
			
		$view = new \OC\Files\View($user.'/files');
		
		//Now delete
		$filesWithError = '';
		$dfiles = '';
		$success = true;
		foreach ($files as $file) {
			
			
			$fileTypeAllowed = \OCA\Files_Filter\Helper::FileTypeAllowed($dir . '/' . $file);
			if($fileTypeAllowed)
				continue;
		
			try {
				if (!\OC\Files\Filesystem::file_exists($dir . '/' . $file))
				{
					$filesWithError .= $file . " does not exist\n";
					$success = false;
				}
				if(!(\OC\Files\Filesystem::isDeletable($dir . '/' . $file)))
				{
					$filesWithError .= $file . " is not deletable\n";
					$success = false;
				}
				
				if(!$view->unlockFile($dir . '/' . $file,ILockingProvider::LOCK_SHARED))
				{
					$filesWithError .= $file . " cant unlock\n";
					$success = false;
				}
				
				if(!\OC\Files\Filesystem::unlink($dir . '/' . $file))
				{
					$filesWithError .= $file . " cant unlink\n";
					$success = false;
				}
				$dfiles .= $file.';';
				
			} catch (\Exception $e) {
				$filesWithError .= $e . "\n";
				$success = false;
			}
		}
		
		if(!$success)
			\OCP\Util::writeLog('files_filter', 'Error files:' .$filesWithError, \OCP\Util::INFO);
		else
			\OCP\Util::writeLog('files_filter', 'Files deleted: '.$dfiles, \OCP\Util::INFO);
		
		
	}
}
