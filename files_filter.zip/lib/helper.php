<?php
/**
 * @author Musa-A. A. <https://github.com/musaa32>

 *
 * @copyright Copyright (c) 2016, Musa-A. A.
 * @license AGPL-3.0
 *
 * This code is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License, version 3,
 * as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License, version 3,
 * along with this program.  If not, see <http://www.gnu.org/licenses/>
 *
 */
namespace OCA\Files_Filter;


class Helper
{

	
	/**
	 * Check if Filter is enabled for current user
	 * 
	 * @return bool
	 */
	public static function FilterEnabledForUser()
	{
		$enabled = \OC::$server->getConfig()->getAppValue('core', 'filetyperes_enabled', 'no') === 'no' ? false : true;
		if($enabled)
		{
			$user = \OCP\User::getUser();
			$filterEnabled_Groups = \OC::$server->getConfig()->getAppValue('core', 'filetype_group', '');
			$excludedGroups = explode(',', $filterEnabled_Groups);
			$usersGroups = \OC_Group::getUserGroups($user);

			
			if(empty($filterEnabled_Groups))
				return false;
			
			if (!empty($usersGroups)) {
				$remainingGroups = array_intersect($usersGroups, $excludedGroups);
							
				if (count($remainingGroups) > 0) {
					return true;
				}
			}				
			
			
		}
	
		return false;
	}
	
	/**
	 * Check if Filetype is allowed
	 * 
	 * @param string $file
	 * @return bool
	 */
	public static function FileTypeAllowed($file)
	{
		$mimeType = \OC_Helper::getMimetypeDetector()->detectPath($file);
		$filetypes = \OC::$server->getConfig()->getAppValue('core', 'allowed_filetypes', '');
		$allowed_types = explode(';', $filetypes);
		$found = array_intersect($allowed_types,array($mimeType));
		return count($found) > 0 ? true : false;
	}
	
	/**
	 * Check if Filetype is allowed
	 * 
	 * @param string $haystack
	 @param string $needle
	 * @return bool
	 
	*/
	public static function startsWith($haystack, $needle) {
		// search backwards starting from haystack length characters from the end
		return $needle === "" || strrpos($haystack, $needle, -strlen($haystack)) !== false;
	}
	
	/**
	 * Check if folder should be ignored
	 * 
	 * @param string $file
	 * @return bool
	 */
	public static function SkipFolder($path)
	{
		
		$ignored_folders = \OC::$server->getConfig()->getAppValue('core', 'ignored_folders', '');
		$ignored_folders = explode(';', $ignored_folders);
		
		foreach($ignored_folders as $folder)
		{
			if(\OCA\Files_Filter\Helper::startsWith($path,$folder))
				return true;
		}
		return false;
	}
	
}
